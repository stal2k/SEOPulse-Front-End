(function ()
{
    'use strict';

    angular
        .module('app.learn.seovault')
        // .controller('SeovaultController', SeovaultController);

    /** @ngInject */
    function SeovaultController(SeovaultData)
    {
        var vm = this;

        // Data
        vm.helloText = HomeData.helloText;

        // Methods

        //////////
    }
})();
