(function ()
{
    'use strict';

    angular
        .module('app.analyze.seometrics')
        .controller('SeometricsController', SeometricsController);

    /** @ngInject */
    function SeometricsController(SeometricsData)
    {
        var vm = this;

        // Data
        // vm.helloText = SeodataHomeData.helloText;

        // Methods

        //////////
    }
})();
