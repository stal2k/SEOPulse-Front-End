(function ()
{
    'use strict';

    angular
        .module('app.analyze.seopulse')
        .controller('SeopulseController', SeopulseController);

    /** @ngInject */
    function SeopulseController(SEOPULSEData)
    {
        // Data
       
        // Methods

        //////////
    }
})();
